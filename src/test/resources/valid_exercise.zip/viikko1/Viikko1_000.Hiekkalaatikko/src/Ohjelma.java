// Tämä ei ole tehtävä, vaan hiekkalaatikko jossa voit vapaasti
// kokeilla kaikenlaista materiaalissa oppimaasi.

public class Ohjelma {

    public static void main(String[] args) {

        // Tänne voit kirjoittaa ohjelmakoodia. Ohjelmasi voit ajaa
        // valitsemalla menusta Run->Run File tai painamalla Shift+F6

    }
}
