import org.junit.Test;
import static org.junit.Assert.*;

public class OhjelmaTest {
    
    public OhjelmaTest() {
    }

    @Test
    public void hiekkalaatikkoVihreakti() {
        assertTrue(true);
    }    
}
